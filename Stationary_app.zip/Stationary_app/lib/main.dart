import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'login_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    // REPLACE WITH YOUR ACTUAL KEYS
    url:'https://cxwgxyajjfzleszkblzc.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN4d2d4eWFqamZ6bGVzemtibHpjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ4MzgwNTgsImV4cCI6MjA4MDQxNDA1OH0.ov8qJMIZCNSCmvEk0WbKnO4f2ddE7S_KrR8rGeOpBmU',
  );

  runApp(const UniversityStationaryApp());
}

class UniversityStationaryApp extends StatelessWidget {
  const UniversityStationaryApp({super.key});

  @override
  Widget build(BuildContext context) {
    const greenColor = Color(0xFF2E7D32);
    const lightGreen = Color(0xFF4CAF50);
    const accentOrange = Color(0xFFFF9800);
    const accentBlue = Color(0xFF2196F3);

    return MaterialApp(
      title: 'Uni-Stationary',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.system,

      // LIGHT THEME
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSeed(seedColor: greenColor, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF0F7F0),
        cardColor: Colors.white,
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          backgroundColor: greenColor,
          elevation: 2,
          titleTextStyle: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
          iconTheme: IconThemeData(color: Colors.white),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFFF5F5F5),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE0E0E0))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: greenColor, width: 2)),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: greenColor,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: accentOrange,
          foregroundColor: Colors.white,
        ),
      ),

      // DARK THEME
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: lightGreen, brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF0D1B0D),
        cardColor: const Color(0xFF1B3A1B),
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          backgroundColor: greenColor,
          elevation: 2,
          titleTextStyle: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
          iconTheme: IconThemeData(color: accentOrange),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF2C2C2C),
          hintStyle: const TextStyle(color: Colors.grey),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF404040))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: accentOrange, width: 2)),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: lightGreen,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: accentBlue,
          foregroundColor: Colors.white,
        ),
      ),

      home: const LoginScreen(),
    );
  }
}
