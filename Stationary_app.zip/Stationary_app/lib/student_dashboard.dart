import 'dart:io';
import 'package:flutter/foundation.dart'; // Required for kIsWeb check
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'database_service.dart';
import 'widgets.dart';
import 'login_screen.dart';

class StudentDashboard extends StatefulWidget {
  final UserModel user;
  const StudentDashboard({super.key, required this.user});

  @override
  State<StudentDashboard> createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  final pinkColor = const Color(0xFFB31645);

  void _showProfileDialog() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircleAvatar(
                  radius: 40,
                  backgroundColor: pinkColor,
                  child: const Icon(Icons.person, size: 40, color: Colors.white)),
              const SizedBox(height: 16),
              Text(widget.user.name,
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.bold)),
              Text("AUID: ${widget.user.auid}",
                  style: const TextStyle(color: Colors.grey)),
              const SizedBox(height: 24),
              _profileRow(Icons.email, widget.user.email),
              _profileRow(Icons.school, widget.user.dept),
              _profileRow(Icons.phone, widget.user.mobile),
              const SizedBox(height: 24),
              SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text("Close"))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _profileRow(IconData icon, String text) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(children: [
        Icon(icon, color: pinkColor, size: 20),
        const SizedBox(width: 12),
        Text(text, style: const TextStyle(fontSize: 16))
      ]));

  void _markAsReceived(String docId) async {
    await Supabase.instance.client
        .from('print_requests')
        .update({'status': 'Received'}).eq('id', docId);
    if (mounted)
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text("Marked as Received!")));
  }

  Future<void> _openFile(String urlString) async {
    try {
      final Uri url = Uri.parse(urlString);
      if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
        throw 'Could not launch $url';
      }
    } catch (e) {
      if (mounted)
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text("Could not open file: $e")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Student Portal"),
        centerTitle: false,
        actions: [
          Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(widget.user.name,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 14)),
                    Text(widget.user.auid,
                        style:
                        const TextStyle(color: Colors.grey, fontSize: 12))
                  ])),
          IconButton(
              onPressed: _showProfileDialog,
              icon: const Icon(Icons.person),
              tooltip: 'Profile'),
          IconButton(
              icon: const Icon(Icons.logout),
              onPressed: () async {
                await Supabase.instance.client.auth.signOut();
                if (mounted)
                  Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (_) => const LoginScreen()));
              }),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showDialog(
            context: context, builder: (_) => UploadDialog(user: widget.user)),
        label: const Text("Upload"),
        icon: const Icon(Icons.upload_file_outlined),
        backgroundColor: pinkColor,
        foregroundColor: Colors.white,
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: Supabase.instance.client
            .from('print_requests')
            .stream(primaryKey: ['id'])
            .eq('auid', widget.user.auid)
            .order('timestamp', ascending: false,),
        builder: (context, snapshot) {
          if (snapshot.hasError)
            return Center(
                child: Text("Error: ${snapshot.error}",
                    style: const TextStyle(color: Colors.red)));
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.folder_open, size: 64, color: Colors.grey),
                      SizedBox(height: 16),
                      Text("No documents found.",
                          style: TextStyle(color: Colors.grey))
                    ]));
          }

          final data = snapshot.data!;
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: data.length,
            itemBuilder: (context, index) {
              final req = PrintRequest.fromJson(data[index]);
              bool canMarkReceived = req.status == 'Completed';
              return StatusCard(
                  req: req,
                  actionLabel: "Mark as Received",
                  onDownload: () => _openFile(req.fileUrl),
                  onAction:
                  canMarkReceived ? () => _markAsReceived(req.id) : null);
            },
          );
        },
      ),
    );
  }
}

class UploadDialog extends StatefulWidget {
  final UserModel user;
  const UploadDialog({super.key, required this.user});
  @override
  State<UploadDialog> createState() => _UploadDialogState();
}

class _UploadDialogState extends State<UploadDialog> {
  bool _isUploading = false;
  File? _selectedFile;
  Uint8List? _selectedFileBytes; // Store file bytes for Web support
  String? _fileName;
  final TextEditingController _commentCtrl =
  TextEditingController(); // Controller for comments
  final pinkColor = const Color(0xFFB31645);

  Future<void> _pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'doc', 'docx', 'jpg', 'png']);
    if (result != null) {
      setState(() {
        if (kIsWeb) {
          // On Web, we must use bytes, not path
          _selectedFileBytes = result.files.single.bytes;
        } else {
          // On Mobile/Desktop, use path
          _selectedFile = File(result.files.single.path!);
        }
        _fileName = result.files.single.name;
      });
    }
  }

  Future<void> _upload() async {
    if ((!kIsWeb && _selectedFile == null) ||
        (kIsWeb && _selectedFileBytes == null)) return;

    setState(() => _isUploading = true);

    try {
      final supabase = Supabase.instance.client;
      final filePath =
          '${widget.user.auid}/${DateTime.now().millisecondsSinceEpoch}_$_fileName';

      if (kIsWeb) {
        // Use uploadBinary for Web
        await supabase.storage
            .from('uploads')
            .uploadBinary(filePath, _selectedFileBytes!);
      } else {
        // Use standard upload for Mobile
        await supabase.storage.from('uploads').upload(filePath, _selectedFile!);
      }

      final publicUrl = supabase.storage.from('uploads').getPublicUrl(filePath);

      await supabase.from('print_requests').insert({
        'auid': widget.user.auid,
        'student_name': widget.user.name,
        'file_name': _fileName,
        'file_url': publicUrl,
        'status': 'Pending',
        'comment': _commentCtrl.text.trim(),
      });

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text("Upload Successful!")));
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Error: $e")));
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    bool hasFile = (kIsWeb && _selectedFileBytes != null) ||
        (!kIsWeb && _selectedFile != null);

    return AlertDialog(
      title: const Text("Upload Document"),
      // Wrap content in SingleChildScrollView to allow scrolling when keyboard opens
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Select a file from your device."),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _pickFile,
                icon: const Icon(Icons.attach_file),
                label: Text(_fileName ?? "Select File"),
                style: ElevatedButton.styleFrom(
                    backgroundColor:
                    hasFile ? pinkColor.withOpacity(0.1) : null,
                    foregroundColor: hasFile ? pinkColor : null,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(vertical: 16)),
              ),
            ),
            const SizedBox(height: 16),
            // Updated TextField to be more visible and handle keyboard
            TextField(
              controller: _commentCtrl,
              scrollPadding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom + 20),
              decoration: const InputDecoration(
                labelText: "Note to Admin(for printing)",
                hintText: "e.g., Color print, 2 copies...",
                border: OutlineInputBorder(),
                filled: true,
                isDense: true,
              ),
              maxLines: 3,
            ),
            if (_isUploading) ...[
              const SizedBox(height: 16),
              const Center(child: CircularProgressIndicator()),
              const Center(
                  child: Padding(
                    padding: EdgeInsets.only(top: 8.0),
                    child: Text("Uploading...",
                        style: TextStyle(fontSize: 12, color: Colors.grey)),
                  ))
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel")),
        FilledButton(
            onPressed: (hasFile && !_isUploading) ? _upload : null,
            child: const Text("Upload")),
      ],
    );
  }
}