class UserModel {
  final String uid;
  final String name;
  final String email;
  final String dept;
  final String mobile;
  final String auid;
  final String role;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    required this.dept,
    required this.mobile,
    required this.auid,
    required this.role,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      uid: json['uid'] ?? '',
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      dept: json['dept'] ?? '',
      mobile: json['mobile'] ?? '',
      auid: json['auid'] ?? '',
      role: json['role'] ?? 'student',
    );
  }
}

class PrintRequest {
  final String id;
  final String auid;
  final String studentName;
  final String fileName;
  final String fileUrl;
  final String status;
  final String timestamp;
  final String comment;

  PrintRequest({
    required this.id,
    required this.auid,
    required this.studentName,
    required this.fileName,
    required this.fileUrl,
    required this.status,
    required this.timestamp,
    required this.comment,
  });

  factory PrintRequest.fromJson(Map<String, dynamic> json) {
    return PrintRequest(
      id: json['id'].toString(),
      auid: json['auid'] ?? '',
      studentName: json['student_name'] ?? '',
      fileName: json['file_name'] ?? '',
      fileUrl: json['file_url'] ?? '',
      status: json['status'] ?? 'Pending',
      timestamp: json['timestamp'] ?? '',
      comment: json['comment'] ?? '',
    );
  }

  // Helper to format the date and time nicely
  String get formattedDate {
    if (timestamp.isEmpty) return '';
    try {
      final DateTime dt = DateTime.parse(timestamp).toLocal();

      String period = dt.hour >= 12 ? 'PM' : 'AM';
      int hour = dt.hour > 12 ? dt.hour - 12 : (dt.hour == 0 ? 12 : dt.hour);
      String minute = dt.minute.toString().padLeft(2, '0');

      // Format: DD/MM/YYYY HH:MM AM/PM
      return "${dt.day}/${dt.month}/${dt.year} $hour:$minute $period";
    } catch (e) {
      return timestamp; // Fallback if parsing fails
    }
  }
}