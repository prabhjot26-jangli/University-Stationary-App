import 'package:flutter/material.dart';
import 'database_service.dart';

class StatusCard extends StatelessWidget {
  final PrintRequest req;
  final String actionLabel;
  final VoidCallback? onAction;
  final VoidCallback? onDownload;

  const StatusCard({
    super.key,
    required this.req,
    required this.actionLabel,
    this.onAction,
    this.onDownload,
  });

  @override
  Widget build(BuildContext context) {
    Color statusColor;
    // 1. Updated Logic to include 'In Queue'
    switch (req.status) {
      case 'In Queue':
        statusColor = Colors.purple;
        break;
      case 'Completed':
        statusColor = Colors.green;
        break;
      case 'Received':
        statusColor = Colors.blue;
        break;
      default:
      // Covers 'Pending'
        statusColor = Colors.orange;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                // 2. Icon now uses the dynamic statusColor instead of grey
                Icon(Icons.description, color: statusColor, size: 30),
                const SizedBox(width: 12),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        req.fileName,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        req.formattedDate,
                        style: const TextStyle(color: Colors.pinkAccent, fontSize: 12, fontWeight: FontWeight.w500),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        "${req.studentName} • ${req.auid}",
                        style: const TextStyle(color: Colors.grey, fontSize: 11),
                      ),
                    ],
                  ),
                ),

                if (onDownload != null)
                  IconButton(
                    icon: const Icon(Icons.download_rounded, color: Color(0xFFB31645)),
                    tooltip: 'Download File',
                    onPressed: onDownload,
                  ),
              ],
            ),
            const SizedBox(height: 12),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: statusColor),
                  ),
                  child: Text(
                    req.status,
                    style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 12),
                  ),
                ),

                if (onAction != null)
                  ElevatedButton(
                    onPressed: onAction,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFB31645),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      textStyle: const TextStyle(fontSize: 12),
                    ),
                    child: Text(actionLabel),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}