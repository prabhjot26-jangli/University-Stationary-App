import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'database_service.dart';
import 'registration_screen.dart';
import 'student_dashboard.dart';
import 'admin_dashboard.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _studentAuidController = TextEditingController();
  final _studentPassController = TextEditingController();
  final _adminAuidController = TextEditingController();
  final _adminPassController = TextEditingController();

  bool _isStudentPassVisible = false;
  bool _isAdminPassVisible = false;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  Future<void> _login(String auid, String password, String expectedRole) async {
    if (auid.isEmpty || password.isEmpty) return;
    setState(() => _isLoading = true);

    try {
      final supabase = Supabase.instance.client;

      // 1. Lookup Email from AUID
      final userQuery = await supabase.from('users').select('email').eq('auid', auid.trim()).maybeSingle();

      if (userQuery == null) throw "User with AUID $auid not found. Please Register first.";
      final String email = userQuery['email'];

      // 2. Sign In
      final AuthResponse res = await supabase.auth.signInWithPassword(email: email, password: password.trim());
      final User? user = res.user;

      if (user != null) {
        // 3. Fetch Profile
        final data = await supabase.from('users').select().eq('uid', user.id).maybeSingle();

        if (data == null) {
          await supabase.auth.signOut();
          throw "Profile error. Please register again.";
        }

        UserModel loggedInUser = UserModel.fromJson(data);

        if (loggedInUser.role == expectedRole) {
          if (mounted) {
            if (expectedRole == 'admin') {
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AdminDashboard()));
            } else {
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => StudentDashboard(user: loggedInUser)));
            }
          }
        } else {
          await supabase.auth.signOut();
          throw "Access Denied: You are not an $expectedRole";
        }
      }
    } on AuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message), backgroundColor: Colors.red));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceAll("Exception:", "")), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cardColor = Theme.of(context).cardColor;
    const pinkColor = Color(0xFFB31645);

    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const Icon(Icons.local_print_shop_outlined, size: 80, color: pinkColor),
              const SizedBox(height: 16),
              const Text("UniStationary", style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
              const Text("Prints and Bindings",style: TextStyle(fontSize: 14, color: Colors.grey)),

              if (_isLoading)
                const Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator())
              else
                Container(
                  height: 450,
                  margin: const EdgeInsets.only(top: 40),
                  decoration: BoxDecoration(
                      color: cardColor,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 20, offset: const Offset(0, 5))]
                  ),
                  child: Column(
                    children: [
                      TabBar(
                          controller: _tabController,
                          labelColor: pinkColor,
                          unselectedLabelColor: Colors.grey,
                          indicatorColor: pinkColor,
                          padding: const EdgeInsets.all(12),
                          tabs: const [Tab(text: "Student"), Tab(text: "Admin")]
                      ),
                      Expanded(
                        child: TabBarView(
                            controller: _tabController,
                            children: [
                              _buildLoginForm(_studentAuidController, _studentPassController, _isStudentPassVisible, (val) => setState(() => _isStudentPassVisible = val), () => _login(_studentAuidController.text, _studentPassController.text, 'student')),
                              _buildLoginForm(_adminAuidController, _adminPassController, _isAdminPassVisible, (val) => setState(() => _isAdminPassVisible = val), () => _login(_adminAuidController.text, _adminPassController.text, 'admin')),
                            ]
                        ),
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 24),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Text("Don't have an account? "),
                GestureDetector(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegistrationScreen())),
                    child: const Text("Register Here", style: TextStyle(color: pinkColor, fontWeight: FontWeight.bold))
                )
              ])
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLoginForm(TextEditingController auidCtrl, TextEditingController passCtrl, bool isVisible, Function(bool) onVisibilityChanged, VoidCallback onLogin) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          TextField(controller: auidCtrl, decoration: const InputDecoration(labelText: "AUID", prefixIcon: Icon(Icons.badge_outlined))),
          const SizedBox(height: 16),
          TextField(controller: passCtrl, obscureText: !isVisible, decoration: InputDecoration(labelText: "Password", prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(icon: Icon(isVisible ? Icons.visibility : Icons.visibility_off), onPressed: () => onVisibilityChanged(!isVisible)))),
          const Spacer(),
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: onLogin, child: const Text("Login"))),
        ],
      ),
    );
  }
}