import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'database_service.dart';
import 'widgets.dart';
import 'login_screen.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final TextEditingController _searchCtrl = TextEditingController();
  String _searchQuery = "";

  late Stream<List<Map<String, dynamic>>> _requestStream;

  @override
  void initState() {
    super.initState();
    _refreshData();
  }

  void _refreshData() {
    setState(() {
      _requestStream = Supabase.instance.client
          .from('print_requests')
          .stream(primaryKey: ['id'])
          .order('timestamp', ascending: false);
    });
  }

  void _updateStatus(String docId, String newStatus) async {
    try {
      await Supabase.instance.client
          .from('print_requests')
          .update({'status': newStatus}).eq('id', docId);

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Status updated to $newStatus")));
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Error: $e"), backgroundColor: Colors.red));
      }
    }
  }

  void _showStatusDialog(String docId, String currentStatus) {
    showDialog(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text("Update Status"),
        children: [
          _buildStatusOption(docId, "Pending", currentStatus),
          _buildStatusOption(docId, "In Queue", currentStatus),
          _buildStatusOption(docId, "Completed", currentStatus),
        ],
      ),
    );
  }

  Widget _buildStatusOption(String docId, String status, String currentStatus) {
    bool isSelected = status == currentStatus;
    Color getColor() {
      switch (status) {
        case 'Pending': return Colors.orange;
        case 'In Queue': return Colors.purple;
        case 'Completed': return Colors.green;
        default: return const Color(0xFFB31645);
      }
    }

    return SimpleDialogOption(
      onPressed: () => _updateStatus(docId, status),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      child: Row(
        children: [
          Icon(
            isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
            color: isSelected ? getColor() : Colors.grey,
            size: 20,
          ),
          const SizedBox(width: 12),
          Text(
            status,
            style: TextStyle(
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              color: isSelected ? getColor() : Theme.of(context).textTheme.bodyMedium?.color, // Adapts to theme
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _openFile(String urlString) async {
    try {
      final Uri url = Uri.parse(urlString);
      if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
        throw 'Could not launch $url';
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("Could not open file: $e"),
            backgroundColor: Colors.red));
      }
    }
  }

  int _getStatusPriority(String status) {
    switch (status) {
      case 'Pending': return 0;
      case 'In Queue': return 1;
      case 'Completed': return 2;
      default: return 3;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Removed fixed background color to let Theme handle Dark/Light mode
      appBar: AppBar(
        title: const Text("Stationary Admin Panel"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: "Refresh Data",
            onPressed: _refreshData,
          ),
          IconButton(
              icon: const Icon(Icons.logout),
              tooltip: "Logout",
              onPressed: () async {
                await Supabase.instance.client.auth.signOut();
                if (mounted)
                  Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (_) => const LoginScreen()));
              }),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: "Search by AUID...",
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                    icon: const Icon(Icons.clear),
                    onPressed: () {
                      _searchCtrl.clear();
                      setState(() => _searchQuery = "");
                    }
                )
                    : null,
                filled: true,
                // Adaptive fill color for Dark Mode
                fillColor: Theme.of(context).brightness == Brightness.dark ? Colors.grey[800] : Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.symmetric(horizontal: 20),
              ),
              onChanged: (val) {
                setState(() => _searchQuery = val.trim());
              },
            ),
          ),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 8),
            child: Text(
                _searchQuery.isEmpty ? "All Incoming Requests" : "Search Results for '$_searchQuery'",
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)
            ),
          ),
          Expanded(
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: _requestStream,
              builder: (context, snapshot) {
                if (snapshot.hasError)
                  return Center(
                      child: Text("Error: ${snapshot.error}",
                          style: const TextStyle(color: Colors.red)));
                if (snapshot.connectionState == ConnectionState.waiting)
                  return const Center(child: CircularProgressIndicator());
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(
                      child: Text("No print jobs found.",
                          style: TextStyle(color: Colors.grey, fontSize: 18)));
                }

                List<PrintRequest> requests = snapshot.data!
                    .map((data) => PrintRequest.fromJson(data))
                    .toList();

                if (_searchQuery.isNotEmpty) {
                  requests = requests.where((req) => req.auid.contains(_searchQuery)).toList();
                }

                requests.sort((a, b) {
                  int priorityA = _getStatusPriority(a.status);
                  int priorityB = _getStatusPriority(b.status);
                  if (priorityA != priorityB) {
                    return priorityA.compareTo(priorityB);
                  } else {
                    return b.timestamp.compareTo(a.timestamp);
                  }
                });

                if (requests.isEmpty) {
                  return const Center(child: Text("No matching student found.", style: TextStyle(color: Colors.grey)));
                }

                return LayoutBuilder(builder: (context, constraints) {
                  bool isDesktop = constraints.maxWidth > 900;
                  if (isDesktop) {
                    return GridView.builder(
                      padding: const EdgeInsets.all(24),
                      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                        maxCrossAxisExtent: 600,
                        childAspectRatio: 2.2,
                        crossAxisSpacing: 24,
                        mainAxisSpacing: 24,
                      ),
                      itemCount: requests.length,
                      itemBuilder: (context, index) => _buildListItem(requests[index]),
                    );
                  } else {
                    return ListView.builder(
                      padding: const EdgeInsets.all(16),
                      // physics ensures you can scroll even if list is short
                      physics: const AlwaysScrollableScrollPhysics(),
                      itemCount: requests.length,
                      itemBuilder: (context, index) => _buildListItem(requests[index]),
                    );
                  }
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildListItem(PrintRequest req) {
    return _AdminStatusCard(
      req: req,
      actionLabel: "Update Status",
      onDownload: () => _openFile(req.fileUrl),
      onAction: () => _showStatusDialog(req.id, req.status),
    );
  }
}

class _AdminStatusCard extends StatelessWidget {
  final PrintRequest req;
  final String actionLabel;
  final VoidCallback? onAction;
  final VoidCallback? onDownload;

  const _AdminStatusCard({
    required this.req,
    required this.actionLabel,
    this.onAction,
    this.onDownload,
  });

  @override
  Widget build(BuildContext context) {
    Color statusColor;
    Color bgColor;

    switch (req.status) {
      case 'Pending':
        statusColor = Colors.orange;
        bgColor = Colors.orange.withOpacity(0.1);
        break;
      case 'In Queue':
        statusColor = Colors.purple;
        bgColor = Colors.purple.withOpacity(0.1);
        break;
      case 'Completed':
        statusColor = Colors.green;
        bgColor = Colors.green.withOpacity(0.1);
        break;
      default:
        statusColor = Colors.grey;
        bgColor = Colors.grey.withOpacity(0.1);
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.description, color: statusColor, size: 36),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        req.fileName,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        overflow: TextOverflow.ellipsis,
                      ),
                      // Date in GREY so it's visible in both Dark/Light modes
                      Text(
                        req.formattedDate,
                        style: const TextStyle(color: Colors.grey, fontSize: 12, fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 4),
                      // REMOVED 'Colors.black87' so it automatically turns White in Dark Mode
                      Text(
                        req.studentName,
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                      ),
                      Text("AUID: ${req.auid}", style: const TextStyle(color: Colors.grey, fontSize: 13)),

                      if (req.comment.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            // Adaptive color for comment box
                              color: Theme.of(context).brightness == Brightness.dark ? Colors.grey[800] : Colors.grey[100],
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.grey)
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.comment, size: 14, color: Colors.grey),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  req.comment,
                                  style: const TextStyle(fontStyle: FontStyle.italic, fontSize: 13),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2,
                                ),
                              ),
                            ],
                          ),
                        )
                      ]
                    ],
                  ),
                ),
                if (onDownload != null)
                  IconButton(
                    icon: const Icon(Icons.download_rounded, color: Color(0xFFB31645)),
                    tooltip: 'Download File',
                    onPressed: onDownload,
                  ),
              ],
            ),
            const Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: bgColor,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: statusColor),
                  ),
                  child: Text(
                    req.status.toUpperCase(),
                    style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 12),
                  ),
                ),
                if (onAction != null)
                  ElevatedButton(
                    onPressed: onAction,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFB31645),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      textStyle: const TextStyle(fontSize: 13),
                    ),
                    child: Text(actionLabel),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}