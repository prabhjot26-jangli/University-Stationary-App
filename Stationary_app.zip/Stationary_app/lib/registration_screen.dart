import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _deptCtrl = TextEditingController();
  final _mobileCtrl = TextEditingController();
  final _auidCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _confirmPassCtrl = TextEditingController();

  bool _isPassVisible = false;
  bool _isConfirmPassVisible = false;
  bool _isLoading = false;

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);

    try {
      final supabase = Supabase.instance.client;
      final auidInput = _auidCtrl.text.trim();

      // Check if AUID exists
      final existingUser = await supabase.from('users').select('auid').eq('auid', auidInput).maybeSingle();
      if (existingUser != null) throw "AUID $auidInput is already registered.";

      final AuthResponse res = await supabase.auth.signUp(
        email: _emailCtrl.text.trim(),
        password: _passCtrl.text.trim(),
      );

      final User? user = res.user;

      if (user != null) {
        await supabase.from('users').insert({
          'uid': user.id,
          'name': _nameCtrl.text.trim(),
          'email': _emailCtrl.text.trim(),
          'dept': _deptCtrl.text.trim(),
          'mobile': _mobileCtrl.text.trim(),
          'auid': auidInput,
          'role': 'student',
        });

        if (mounted) {
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (context) => AlertDialog(
              title: const Text("Registration Successful"),
              content: const Text("Please login with your new account."),
              actions: [TextButton(onPressed: () {Navigator.pop(context); Navigator.pop(context);}, child: const Text("OK"))],
            ),
          );
        }
      }
    } on AuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message), backgroundColor: Colors.red));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Student Registration")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text("Create Account", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const Text("Fill in your details.", style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 24),
              TextFormField(controller: _nameCtrl, decoration: const InputDecoration(labelText: "Full Name", prefixIcon: Icon(Icons.person_outline)), validator: (v) => v!.isEmpty ? "Required" : null),
              const SizedBox(height: 16),
              TextFormField(controller: _emailCtrl, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: "Contact Email", prefixIcon: Icon(Icons.email_outlined)), validator: (v) => v!.isEmpty ? "Required" : null),
              const SizedBox(height: 16),
              Row(children: [
                Expanded(child: TextFormField(controller: _deptCtrl, decoration: const InputDecoration(labelText: "Dept", prefixIcon: Icon(Icons.school_outlined)), validator: (v) => v!.isEmpty ? "Required" : null)),
                const SizedBox(width: 16),
                Expanded(child: TextFormField(controller: _mobileCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: "Mobile No.", prefixIcon: Icon(Icons.phone_android)), validator: (v) => (v != null && RegExp(r'^[0-9]{10}$').hasMatch(v)) ? null : "Invalid"))
              ]),
              const SizedBox(height: 16),
              TextFormField(controller: _auidCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "AUID (9 Digits)", prefixIcon: Icon(Icons.badge_outlined)), validator: (v) => (v != null && RegExp(r'^[0-9]{9}$').hasMatch(v)) ? null : "Invalid"),
              const SizedBox(height: 16),
              TextFormField(controller: _passCtrl, obscureText: !_isPassVisible, decoration: InputDecoration(labelText: "Password", prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(icon: Icon(_isPassVisible ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => _isPassVisible = !_isPassVisible))), validator: (v) => v!.length < 6 ? "Min 6 chars" : null),
              const SizedBox(height: 16),
              TextFormField(controller: _confirmPassCtrl, obscureText: !_isConfirmPassVisible, decoration: InputDecoration(labelText: "Confirm Password", prefixIcon: const Icon(Icons.lock_clock_outlined), suffixIcon: IconButton(icon: Icon(_isConfirmPassVisible ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => _isConfirmPassVisible = !_isConfirmPassVisible))), validator: (v) => v != _passCtrl.text ? "Mismatch" : null),
              const SizedBox(height: 32),
              _isLoading ? const Center(child: CircularProgressIndicator()) : ElevatedButton(onPressed: _register, child: const Text("Register")),
            ],
          ),
        ),
      ),
    );
  }
}