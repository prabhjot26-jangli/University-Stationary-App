# Supabase Setup Guide (Simple & Easy)

## Step 1: Create Supabase Project
1. Go to [Supabase](https://supabase.com/)
2. Click "Start your project"
3. Sign up with email
4. Create new project:
   - Name: `UniStationary`
   - Password: Create strong password
   - Region: Choose closest to you
5. Wait for project to initialize (2-3 minutes)

## Step 2: Get Your Credentials
1. In Supabase dashboard, go to **Settings** → **API**
2. Copy:
   - **Project URL** (looks like: `https://xxxxx.supabase.co`)
   - **Anon Key** (public key)

## Step 3: Update Flutter App
Open `lib/main.dart` and replace:
```dart
await Supabase.initialize(
  url: 'YOUR_SUPABASE_URL',        // Paste your Project URL here
  anonKey: 'YOUR_SUPABASE_ANON_KEY', // Paste your Anon Key here
);
```

Example:
```dart
await Supabase.initialize(
  url: 'https://abcdef123456.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
);
```

## Step 4: Create Database Table
1. In Supabase, go to **SQL Editor**
2. Click **New Query**
3. Paste this SQL:

```sql
CREATE TABLE print_requests (
  id TEXT PRIMARY KEY,
  auid TEXT NOT NULL,
  student_name TEXT NOT NULL,
  file_name TEXT NOT NULL,
  original_file_name TEXT,
  timestamp TEXT NOT NULL,
  status TEXT NOT NULL,
  download_url TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_auid ON print_requests(auid);
CREATE INDEX idx_status ON print_requests(status);
```

4. Click **Run**

## Step 5: Create Storage Bucket
1. In Supabase, go to **Storage**
2. Click **Create new bucket**
3. Name: `uploads`
4. Make it **Public** (important for downloads)
5. Click **Create bucket**

## Step 6: Set Storage Permissions
1. Go to **Storage** → **uploads** bucket
2. Click **Policies** tab
3. Click **New policy** → **For full customization**
4. Paste this policy:

```sql
CREATE POLICY "Allow public read" ON storage.objects
FOR SELECT USING (bucket_id = 'uploads');

CREATE POLICY "Allow authenticated upload" ON storage.objects
FOR INSERT WITH CHECK (bucket_id = 'uploads');
```

5. Click **Review** → **Save policy**

## Step 7: Run the App
```bash
flutter pub get
flutter run
```

## Testing

### Student:
1. Register account
2. Upload file
3. File appears in Supabase Storage
4. Metadata in database

### Admin:
1. Login: `admin` / `admin123`
2. See all uploads
3. Update status
4. Download files

## Troubleshooting

**"Connection refused"**
- Check URL is correct (no typos)
- Check internet connection

**"Invalid API key"**
- Copy Anon Key again from Settings → API
- Make sure it's the public key, not secret

**"Bucket not found"**
- Create `uploads` bucket in Storage
- Make it Public

**"Permission denied"**
- Check storage policies are set
- Bucket should be Public

**"Table not found"**
- Run the SQL query in SQL Editor
- Check table name is `print_requests`

## Free Tier Limits
- 500 MB storage
- 2 GB bandwidth/month
- Enough for testing!

Upgrade anytime if needed.
