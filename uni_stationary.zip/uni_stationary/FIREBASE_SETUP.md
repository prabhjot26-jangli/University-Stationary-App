# Firebase Setup Guide

## Step 1: Create Firebase Project
1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Add project"
3. Enter project name (e.g., "UniStationary")
4. Click "Create project"

## Step 2: Add Android App
1. In Firebase Console, click "Add app" → Select Android
2. Enter package name: `com.example.uni_stationary`
3. Download `google-services.json`
4. Place it in: `android/app/google-services.json`

## Step 3: Enable Firestore Database
1. In Firebase Console, go to "Firestore Database"
2. Click "Create database"
3. Select "Start in test mode" (for development)
4. Choose region (closest to you)
5. Click "Create"

## Step 4: Enable Storage
1. In Firebase Console, go to "Storage"
2. Click "Get started"
3. Select "Start in test mode"
4. Choose region (same as Firestore)
5. Click "Done"

## Step 5: Update Firebase Config
1. In Firebase Console, go to Project Settings (gear icon)
2. Copy your project credentials
3. Update `lib/firebase_options.dart`:
   - Replace `YOUR_ANDROID_API_KEY` with your API Key
   - Replace `YOUR_ANDROID_APP_ID` with your App ID
   - Replace `YOUR_MESSAGING_SENDER_ID` with your Sender ID
   - Replace `YOUR_PROJECT_ID` with your Project ID

## Step 6: Update Android Build Files
1. Open `android/build.gradle`
2. Add to dependencies:
   ```gradle
   classpath 'com.google.gms:google-services:4.3.15'
   ```

2. Open `android/app/build.gradle`
3. Add at the bottom:
   ```gradle
   apply plugin: 'com.google.gms.google-services'
   ```

## Step 7: Run the App
```bash
flutter pub get
flutter run
```

## Testing the App

### Student Flow:
1. Register a new student account
2. Upload a document (file picker will open)
3. File uploads to Firebase Storage
4. Metadata saved to Firestore

### Admin Flow:
1. Login with: `admin` / `admin123`
2. View all student uploads
3. Update status: Pending → In Queue → Completed
4. Download files directly

## Firestore Security Rules (Test Mode)
For production, update rules in Firestore:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /print_requests/{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## Storage Security Rules (Test Mode)
For production, update rules in Storage:
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /uploads/{allPaths=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## Troubleshooting

**Issue: "google-services.json not found"**
- Make sure file is in `android/app/` directory

**Issue: "Firebase not initialized"**
- Check firebase_options.dart has correct credentials

**Issue: "Permission denied" errors**
- Switch Firestore/Storage to "Test mode" temporarily
- Or update security rules

**Issue: File upload fails**
- Check Storage bucket exists
- Verify file size is reasonable
