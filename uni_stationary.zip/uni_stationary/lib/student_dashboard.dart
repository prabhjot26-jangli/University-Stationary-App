import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'mock_database.dart';
import 'widgets.dart';
import 'login_screen.dart';
import 'firebase_service.dart';

class StudentDashboard extends StatefulWidget {
  final User user;

  const StudentDashboard({super.key, required this.user});

  @override
  State<StudentDashboard> createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> with SingleTickerProviderStateMixin {
  late AnimationController _fabController;
  List<PrintRequest> _requests = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fabController = AnimationController(duration: const Duration(milliseconds: 500), vsync: this);
    _fabController.forward();
    _loadRequests();
  }

  Future<void> _loadRequests() async {
    try {
      final requests = await FirebaseService.getStudentRequests(widget.user.auid);
      setState(() {
        _requests = requests;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading requests: $e')),
        );
      }
    }
  }

  void _showProfile() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.teal.withOpacity(0.1), Colors.blue.withOpacity(0.1)],
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.teal.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.person, size: 40, color: Colors.teal),
                ),
                const SizedBox(height: 16),
                Text(
                  widget.user.name,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),
                _profileRow(Icons.email, 'Email', widget.user.email),
                _profileRow(Icons.business, 'Department', widget.user.dept),
                _profileRow(Icons.calendar_today, 'Year', widget.user.year),
                _profileRow(Icons.badge, 'AUID', widget.user.auid),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                  child: const Text('Close'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _profileRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, color: Colors.teal, size: 20),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
              Text(value, style: const TextStyle(fontWeight: FontWeight.w500)),
            ],
          ),
        ],
      ),
    );
  }

  void _uploadDocument() async {
    try {
      final file = await FirebaseService.pickFile();
      if (file == null) return;

      if (!mounted) return;
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(
          child: CircularProgressIndicator(),
        ),
      );

      final newRequest = PrintRequest(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        auid: widget.user.auid,
        studentName: widget.user.name,
        fileName: file.name,
        timestamp: DateTime.now(),
        status: 'Pending',
      );

      await FirebaseService.uploadFile(newRequest, file);

      if (mounted) {
        Navigator.pop(context);
        _loadRequests();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Document uploaded successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('❌ Upload failed: $e')),
        );
      }
    }
  }

  void _markAsReceived(PrintRequest request) async {
    try {
      await FirebaseService.updateStatus(request.id, 'Received');
      _loadRequests();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ Marked as received')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  void _downloadFile(PrintRequest request) async {
    if (request.downloadUrl == null) return;
    try {
      await launchUrl(Uri.parse(request.downloadUrl!));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  void _logout() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushReplacement(
                context,
                PageRouteBuilder(
                  pageBuilder: (context, animation, secondaryAnimation) => const LoginScreen(),
                  transitionsBuilder: (context, animation, secondaryAnimation, child) {
                    return FadeTransition(opacity: animation, child: child);
                  },
                ),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _fabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.dashboard),
            const SizedBox(width: 8),
            Expanded(child: Text('Welcome, ${widget.user.name}')),
          ],
        ),
        backgroundColor: Colors.teal,
        elevation: 8,
        actions: [
          IconButton(
            icon: const Icon(Icons.person),
            onPressed: _showProfile,
            tooltip: 'Profile',
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
            tooltip: 'Logout',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _requests.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.inbox, size: 64, color: Colors.grey[300]),
                      const SizedBox(height: 16),
                      Text('No print requests yet', style: TextStyle(color: Colors.grey[600], fontSize: 16)),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _requests.length,
                  itemBuilder: (context, index) {
                    final request = _requests[index];
                    return StatusCard(
                      request: request,
                      onAction: request.status == 'Completed' ? () => _markAsReceived(request) : null,
                      onDownload: request.downloadUrl != null ? () => _downloadFile(request) : null,
                    );
                  },
                ),
      floatingActionButton: ScaleTransition(
        scale: Tween<double>(begin: 0.0, end: 1.0).animate(
          CurvedAnimation(parent: _fabController, curve: Curves.elasticOut),
        ),
        child: FloatingActionButton.extended(
          onPressed: _uploadDocument,
          backgroundColor: Colors.teal,
          icon: const Icon(Icons.upload_file),
          label: const Text('Upload'),
        ),
      ),
    );
  }
}

