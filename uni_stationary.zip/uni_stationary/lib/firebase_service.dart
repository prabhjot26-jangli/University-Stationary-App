import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:file_picker/file_picker.dart';
import 'mock_database.dart';

class FirebaseService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static final FirebaseStorage _storage = FirebaseStorage.instance;

  static Future<void> uploadFile(
      PrintRequest request, PlatformFile file) async {
    try {
      final fileName =
          '${request.auid}_${DateTime.now().millisecondsSinceEpoch}_${file.name}';
      final ref = _storage.ref('uploads/$fileName');

      await ref.putData(file.bytes!);
      final downloadUrl = await ref.getDownloadURL();

      await _firestore.collection('print_requests').doc(request.id).set({
        'id': request.id,
        'auid': request.auid,
        'studentName': request.studentName,
        'fileName': request.fileName,
        'originalFileName': file.name,
        'timestamp': request.timestamp.toIso8601String(),
        'status': request.status,
        'downloadUrl': downloadUrl,
      });
    } catch (e) {
      throw Exception('Upload failed: $e');
    }
  }

  static Future<List<PrintRequest>> getStudentRequests(String auid) async {
    try {
      final snapshot = await _firestore
          .collection('print_requests')
          .where('auid', isEqualTo: auid)
          .orderBy('timestamp', descending: true)
          .get();

      return snapshot.docs.map((doc) {
        final data = doc.data();
        return PrintRequest(
          id: data['id'],
          auid: data['auid'],
          studentName: data['studentName'],
          fileName: data['fileName'],
          timestamp: DateTime.parse(data['timestamp']),
          status: data['status'],
          downloadUrl: data['downloadUrl'],
        );
      }).toList();
    } catch (e) {
      throw Exception('Failed to fetch requests: $e');
    }
  }

  static Future<List<PrintRequest>> getAllRequests() async {
    try {
      final snapshot = await _firestore
          .collection('print_requests')
          .orderBy('timestamp', descending: true)
          .get();

      return snapshot.docs.map((doc) {
        final data = doc.data();
        return PrintRequest(
          id: data['id'],
          auid: data['auid'],
          studentName: data['studentName'],
          fileName: data['fileName'],
          timestamp: DateTime.parse(data['timestamp']),
          status: data['status'],
          downloadUrl: data['downloadUrl'],
        );
      }).toList();
    } catch (e) {
      throw Exception('Failed to fetch requests: $e');
    }
  }

  static Future<void> updateStatus(String requestId, String newStatus) async {
    try {
      await _firestore.collection('print_requests').doc(requestId).update({
        'status': newStatus,
      });
    } catch (e) {
      throw Exception('Failed to update status: $e');
    }
  }

  static Future<PlatformFile?> pickFile() async {
    try {
      final result = await FilePicker.platform.pickFiles();
      return result?.files.first;
    } catch (e) {
      throw Exception('File pick failed: $e');
    }
  }
}
