class User {
  final String name;
  final String email;
  final String dept;
  final String year;
  final String auid;
  final String password;

  User({
    required this.name,
    required this.email,
    required this.dept,
    required this.year,
    required this.auid,
    required this.password,
  });
}

class PrintRequest {
  final String id;
  final String auid;
  final String studentName;
  final String fileName;
  final DateTime timestamp;
  String status;
  final String? downloadUrl;

  PrintRequest({
    required this.id,
    required this.auid,
    required this.studentName,
    required this.fileName,
    required this.timestamp,
    required this.status,
    this.downloadUrl,
  });
}

class MockDatabase {
  static final List<User> students = [];
  static final List<PrintRequest> requests = [];
  
  static const String adminUsername = 'admin';
  static const String adminPassword = 'admin123';
}

