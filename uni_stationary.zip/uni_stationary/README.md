# UniStationary App

University Stationary Management App built with Flutter.

## Setup Instructions

1. Open the `uni_stationary` folder in Android Studio
2. Run `flutter pub get` to install dependencies
3. Connect a device or start an emulator
4. Run the app using the Run button or `flutter run`

## Default Credentials

**Admin Login:**
- Username: `admin`
- Password: `admin123`

**Student Login:**
- Register a new student account first
- Then login with your AUID and password

## Features

- Student registration and login
- Document upload with status tracking
- Admin dashboard with search and sort
- Status workflow: Pending → In Queue → Completed → Received
